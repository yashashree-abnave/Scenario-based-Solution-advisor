# Scenario Based Solution Advisor (RAG + Web Search)

This application is a advanced **Retrieval-Augmented Generation (RAG)** system designed to provide personalized advice by adopting the persona of historic figures (e.g., Mahatma Gandhi).

## 💡 How it works (The RAG Architecture)
This project implements the standard RAG pipeline with an intelligent fallback:

1.  **Retrieval**: 
    -   **Primary**: Ingests user-uploaded autobiographies (PDFs), splits them into chunks, embeds them using Google Gemini Embeddings, and stores them in **ChromaDB**. It *retrieves* the most relevant "wisdom" based on your situation.
    -   **Secondary (Fallback)**: If no PDFs are provided, it performs a live **Internet Search (Web RAG)** using DuckDuckGo to retrieve the personality's teachings from the web.
2.  **Augmentation**: 
    -   The system *augments* the LLM's prompt with this retrieved context (either from the PDF or the Web).
3.  **Generation**: 
    -   **Google Gemini 2.0 Flash** *generates* a profound, first-person response by synthesizing the retrieved principles and applying them to your modern situation.

## 🚀 Features
-   **Persona Adherence**: Strictly role-plays as the selected advisor.
-   **Reasoning Engine**: Instead of just matching keywords, it applies deep principles (e.g., "Ahimsa") to solve modern problems (e.g., "Workplace Stress").
-   **Modern Chat UI**: Full conversational interface with history and custom styling.

## 🛠️ Tech Stack
-   **LLM**: Google Gemini 2.0 Flash
-   **Vector Store**: ChromaDB
-   **Orchestration**: LangChain
-   **Frontend**: Streamlit
-   **Search Tool**: DuckDuckGo

## 📦 Setup
1.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
2.  **Run the Application**:
    ```bash
    streamlit run app.py
    ```
