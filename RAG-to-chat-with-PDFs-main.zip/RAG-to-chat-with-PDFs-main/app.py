import streamlit as st
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from langchain_community.vectorstores import Chroma
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains.question_answering import load_qa_chain
from langchain.prompts import PromptTemplate
from langchain_community.tools import DuckDuckGoSearchRun

GOOGLE_API_KEY = 'AIzaSyDw-Dhy-fIhAqinBUh9hEeyaQf8fkRO46Q'

genai.configure(api_key=GOOGLE_API_KEY)

def get_pdf_text(pdf_docs):
    text=""
    for pdf in pdf_docs:
        pdf_reader= PdfReader(pdf)
        for page in pdf_reader.pages:
            text+= page.extract_text()
    return  text



def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=10000, chunk_overlap=1000)
    chunks = text_splitter.split_text(text)
    return chunks


def get_vector_store(text_chunks):
    embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")
    vector_store = Chroma.from_texts(text_chunks, embedding=embeddings, persist_directory="chroma_db")
    vector_store.persist()


def get_conversational_chain(personality):

    prompt_template = f"""
    You are {personality}. The provided context contains your autobiography, principles, and teachings.
    
    Context:\n {{context}}\n
    
    User's Situation/Question: \n{{question}}\n

    Task:
    Provide advice to the user by applying the principles, values, and experiences found in the Context above.
    Do not strictly search for the exact keywords of the situation. Instead, think: "How would I, {personality}, handle this based on my life?"
    If the context contains relevant principles (e.g., non-violence, truth, perseverance), apply them to the user's modern situation.
    Speak in the first person ("I"). Be profound and helpful.
    
    Answer:
    """

    model = ChatGoogleGenerativeAI(model="gemini-2.0-flash",
                             temperature=0.9)

    prompt = PromptTemplate(template = prompt_template, input_variables = ["context", "question"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)

    return chain



def user_input_handler(user_question, personality):
    embeddings = GoogleGenerativeAIEmbeddings(model = "models/embedding-001")
    
    # Try to load vector store and search
    try:
        new_db = Chroma(persist_directory="chroma_db", embedding_function=embeddings)
        docs = new_db.similarity_search(user_question)
    except Exception:
        docs = []

    # If no documents found (no PDF uploaded or empty store), fall back to Web Search
    if not docs:
        search = DuckDuckGoSearchRun()
        search_query = f"{personality} beliefs and teachings on {user_question}"
        web_content = search.run(search_query)
        # Create a dummy document object or just pass text? Chain expects 'input_documents' which are Objects with page_content
        # Let's mock the document object structure for the chain
        from langchain.docstore.document import Document
        docs = [Document(page_content=f"Source: Internet Search for '{search_query}'\n\n{web_content}")]
        
        # Add a visual indicator for the user
        st.toast(f"Searching the web for {personality}'s views...", icon="🌐")

    chain = get_conversational_chain(personality)

    
    response = chain(
        {"input_documents":docs, "question": user_question}
        , return_only_outputs=True)

    return response["output_text"]


def main():
    st.set_page_config("Scenario Based Solution Advisor", page_icon="🧘‍♂️")
    
    # Custom CSS for Advisor Theme
    st.markdown("""
        <style>
        .stApp {
            background-color: #f8f9fa;
        }
        h1 {
            color: #2c3e50;
            font-family: 'Georgia', serif;
        }
        .stChatMessage {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            margin-bottom: 10px;
        }
        .stChatInput {
            border-radius: 20px;
        }
        div[data-testid="stSidebar"] {
            background-color: #e9ecef;
        }
        </style>
    """, unsafe_allow_html=True)

    st.header("🧘‍♂️ Scenario Based Solution Advisor")
    
    with st.sidebar:
        st.title("Settings")
        personality = st.text_input("Who is the Advisor?", value="Mahatma Gandhi")
        pdf_docs = st.file_uploader(f"Upload {personality}'s Autobiography/Writings", accept_multiple_files=True)
        
        if st.button("Submit & Process"):
            with st.spinner("Processing..."):
                raw_text = get_pdf_text(pdf_docs)
                text_chunks = get_text_chunks(raw_text)
                get_vector_store(text_chunks)
                st.success("Done")
                
        if st.button("Clear Conversation"):
            st.session_state.messages = []
            st.rerun()

    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # React to user input
    if prompt := st.chat_input(f"Ask {personality} for advice..."):
        # Display user message in chat message container
        st.chat_message("user").markdown(prompt)
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})

        with st.spinner(f"{personality} is pondering..."):
            try:
                response = user_input_handler(prompt, personality)
                
                # Display assistant response in chat message container
                with st.chat_message("assistant"):
                    st.markdown(response)
                
                # Add assistant response to chat history
                st.session_state.messages.append({"role": "assistant", "content": response})
            except Exception as e:
                st.error(f"An error occurred: {e}")

if __name__ == "__main__":
    main()